# language identifiers that currently are not supported by python-babel.
# see i18n.utils, Locale.parse()
EXCLUDED_LANGUAGE_IDENTIFIERS = ["nso", "oci-es", "x-i18n", "st"]
INCLUDED_LICENSE_VERSIONS = ["4.0", "3.0", "1.0"]
