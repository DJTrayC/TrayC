# A valid language code that happens to not have
# any translations in our license data.
# (as of 2020-07-08).
UNUSED_LANGUAGE = "cs"
